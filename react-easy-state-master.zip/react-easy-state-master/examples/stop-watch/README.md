# Stopwatch · [Live Demo](https://RisingStack.github.io/react-easy-state/examples/stop-watch/build)

A simple stopwatch. It uses a single global store with a mix of normal properties, getters and methods. You can find a tutorial about creating the stopwatch [here](https://hackernoon.com/introducing-react-easy-state-1210a156fa16).
