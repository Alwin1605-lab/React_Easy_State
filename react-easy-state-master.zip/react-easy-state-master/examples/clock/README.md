# Clock widget · [Live Demo](https://RisingStack.github.io/react-easy-state/examples/clock/build)

A super simple digital clock widget. It uses local function component state only and no global store, which is the general rule for **reusable** components and widgets.
