# Contact Table · [Live Demo](https://RisingStack.github.io/react-easy-state/examples/contacts/build)

An editable contact list, which demonstrates how to balance between local component state and global stores. It manages the central data and logic in a global store and keeps temporary utility data in class component states. Dependency injection is handled by plain imports and react props.
