# Pokédex - [Live deploy](https://pokedex.danielgrgly.now.sh/)
A showcase app bootstrapped with [Create React App](https://github.com/facebook/create-react-app) and built with [react-easy-state](https://github.com/risingstack/react-easy-state) and GraphQL.

The API we use to load data of the Pokémon can be found [here](https://graphql-pokemon.now.sh/).
