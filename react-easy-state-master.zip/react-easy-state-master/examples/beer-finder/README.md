# Beer Finder · [Live Demo](https://RisingStack.github.io/react-easy-state/examples/beer-finder/build)

An app to find matching beers for your meal. It features networking and async actions with a mix of global and local state. The styling is partially done with the awesome [React Material UI](http://www.material-ui.com/#/) library.
