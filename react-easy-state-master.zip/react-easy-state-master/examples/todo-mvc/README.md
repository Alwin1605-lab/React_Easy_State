# TodoMVC · [Live Demo](https://RisingStack.github.io/react-easy-state/examples/todo-mvc/build)

This is a lighter version of the well-known React [TodoMVC](http://todomvc.com/). It handles all of the state in a separate global store and relies heavily on JS getters and setter to provide a clear and simple state management. Be sure to click all the buttons in the demo that you can find.
